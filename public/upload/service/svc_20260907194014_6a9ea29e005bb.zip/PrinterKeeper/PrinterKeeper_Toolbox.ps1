﻿# ============================================================
# PrinterKeeper 打印机管理工具箱（GUI 启动器）
# 版本: 1.0  |  入口: 兼容版（Win10/11）
# 作用: 以图形界面运行「兼容版」三个脚本（连接打印机 / 权限修复 / 系统还原）
# 依赖: Windows PowerShell 5.1 + .NET Framework 4.x（Win10/11 自带，零额外安装）
# 运行: 双击「启动工具.bat」即可（推荐），或右键本文件 -> 使用 PowerShell 运行
# ============================================================
$ErrorActionPreference = 'Stop'

Add-Type -AssemblyName PresentationFramework, PresentationCore, WindowsBase, System.Xaml

$scriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Path
$compatDir  = Join-Path $scriptDir '兼容版'
$connectPath  = Join-Path $compatDir '打印机连接脚本_兼容版.ps1'
$permPath     = Join-Path $compatDir '权限修复脚本_兼容版.ps1'
$restorePath  = Join-Path $compatDir '系统默认还原服务_兼容版.ps1'

# ---------- 界面定义 ----------
[xml]$xaml = @'
<Window xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
        xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
        Title="PrinterKeeper 打印机管理工具箱"
        Width="960" Height="690" MinWidth="860" MinHeight="620"
        WindowStartupLocation="CenterScreen" FontFamily="Microsoft YaHei UI"
        Background="#0F1B2D">
    <Window.Resources>
        <LinearGradientBrush x:Key="AccSky" StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#3B82F6" Offset="0"/>
            <GradientStop Color="#38BDF8" Offset="1"/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key="AccAmber" StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#F59E0B" Offset="0"/>
            <GradientStop Color="#FBBF24" Offset="1"/>
        </LinearGradientBrush>
        <LinearGradientBrush x:Key="AccGreen" StartPoint="0,0" EndPoint="1,1">
            <GradientStop Color="#10B981" Offset="0"/>
            <GradientStop Color="#34D399" Offset="1"/>
        </LinearGradientBrush>

        <Style x:Key="Card" TargetType="Border">
            <Setter Property="Background" Value="#16263F"/>
            <Setter Property="BorderBrush" Value="#26395A"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="CornerRadius" Value="16"/>
            <Setter Property="Padding" Value="18"/>
        </Style>

        <Style x:Key="RunBtn" TargetType="Button">
            <Setter Property="Foreground" Value="White"/>
            <Setter Property="FontSize" Value="14"/>
            <Setter Property="FontWeight" Value="SemiBold"/>
            <Setter Property="Padding" Value="10,9"/>
            <Setter Property="Margin" Value="0,14,0,0"/>
            <Setter Property="BorderThickness" Value="0"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="bd" CornerRadius="10" Background="{TemplateBinding Background}" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="bd" Property="Opacity" Value="0.85"/>
                            </Trigger>
                            <Trigger Property="IsPressed" Value="True">
                                <Setter TargetName="bd" Property="Opacity" Value="0.65"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="GhostBtn" TargetType="Button">
            <Setter Property="Foreground" Value="#A9B8CE"/>
            <Setter Property="FontSize" Value="12"/>
            <Setter Property="Padding" Value="12,6"/>
            <Setter Property="Margin" Value="6,0,0,0"/>
            <Setter Property="Background" Value="#1C2C45"/>
            <Setter Property="BorderBrush" Value="#31456A"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Cursor" Value="Hand"/>
            <Setter Property="Template">
                <Setter.Value>
                    <ControlTemplate TargetType="Button">
                        <Border x:Name="gb" CornerRadius="8" Background="{TemplateBinding Background}" BorderBrush="{TemplateBinding BorderBrush}" BorderThickness="1" Padding="{TemplateBinding Padding}">
                            <ContentPresenter HorizontalAlignment="Center" VerticalAlignment="Center"/>
                        </Border>
                        <ControlTemplate.Triggers>
                            <Trigger Property="IsMouseOver" Value="True">
                                <Setter TargetName="gb" Property="Background" Value="#24375A"/>
                            </Trigger>
                            <Trigger Property="IsEnabled" Value="False">
                                <Setter TargetName="gb" Property="Opacity" Value="0.45"/>
                            </Trigger>
                        </ControlTemplate.Triggers>
                    </ControlTemplate>
                </Setter.Value>
            </Setter>
        </Style>

        <Style x:Key="Badge" TargetType="Border">
            <Setter Property="CornerRadius" Value="20"/>
            <Setter Property="Background" Value="#123047"/>
            <Setter Property="BorderBrush" Value="#38BDF8"/>
            <Setter Property="BorderThickness" Value="1"/>
            <Setter Property="Padding" Value="9,2"/>
        </Style>
    </Window.Resources>

    <Grid Margin="24,20,24,16">
        <Grid.RowDefinitions>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="Auto"/>
            <RowDefinition Height="*"/>
            <RowDefinition Height="Auto"/>
        </Grid.RowDefinitions>

        <!-- 头部 -->
        <StackPanel Orientation="Horizontal">
            <Border Width="54" Height="54" CornerRadius="15" Background="#1E3A5F" BorderBrush="#38BDF8" BorderThickness="1">
                <TextBlock Text="🖨️" FontSize="28" HorizontalAlignment="Center" VerticalAlignment="Center"/>
            </Border>
            <StackPanel Margin="14,0,0,0" VerticalAlignment="Center">
                <TextBlock Text="PrinterKeeper 打印机管理工具箱" FontSize="21" FontWeight="Bold" Foreground="White"/>
                <StackPanel Orientation="Horizontal" Margin="0,4,0,0">
                    <TextBlock Text="网络打印机连接 · 权限修复 · 系统还原" FontSize="12" Foreground="#93A4BC"/>
                    <Border Style="{StaticResource Badge}" Margin="10,0,0,0">
                        <TextBlock Text="兼容版入口（Win10/11）" Foreground="#7DD3FC" FontSize="11"/>
                    </Border>
                </StackPanel>
            </StackPanel>
        </StackPanel>

        <!-- 三个功能卡片 -->
        <UniformGrid Grid.Row="1" Columns="3" Margin="0,20,0,0">
            <Border Style="{StaticResource Card}" Margin="0,0,10,0">
                <StackPanel>
                    <TextBlock Text="🖨️" FontSize="32"/>
                    <TextBlock Text="连接打印机" FontSize="16" FontWeight="Bold" Foreground="White" Margin="0,8,0,0"/>
                    <Border Style="{StaticResource Badge}" Margin="0,8,0,0" HorizontalAlignment="Left">
                        <TextBlock Text="兼容版 v4.0" Foreground="#7DD3FC" FontSize="11"/>
                    </Border>
                    <TextBlock Text="自动发现共享、智能选择驱动，兼容旧式 SMB1 打印机，支持 TCP/IP 端口直连。" FontSize="12" Foreground="#A9B8CE" TextWrapping="Wrap" Margin="0,10,0,0" LineHeight="19"/>
                    <Button x:Name="BtnConnect" Style="{StaticResource RunBtn}" Background="{StaticResource AccSky}" Content="运行脚本"/>
                </StackPanel>
            </Border>
            <Border Style="{StaticResource Card}" Margin="5,0">
                <StackPanel>
                    <TextBlock Text="🛠️" FontSize="32"/>
                    <TextBlock Text="权限修复" FontSize="16" FontWeight="Bold" Foreground="White" Margin="0,8,0,0"/>
                    <Border Style="{StaticResource Badge}" Margin="0,8,0,0" HorizontalAlignment="Left">
                        <TextBlock Text="兼容版 v2.5" Foreground="#FCD34D" FontSize="11"/>
                    </Border>
                    <TextBlock Text="修复系统策略、服务、防火墙与来宾访问，为旧式打印机连接铺路（可选启用 SMB1）。" FontSize="12" Foreground="#A9B8CE" TextWrapping="Wrap" Margin="0,10,0,0" LineHeight="19"/>
                    <Button x:Name="BtnPerm" Style="{StaticResource RunBtn}" Background="{StaticResource AccAmber}" Content="运行脚本"/>
                </StackPanel>
            </Border>
            <Border Style="{StaticResource Card}" Margin="10,0,0,0">
                <StackPanel>
                    <TextBlock Text="♻️" FontSize="32"/>
                    <TextBlock Text="系统还原" FontSize="16" FontWeight="Bold" Foreground="White" Margin="0,8,0,0"/>
                    <Border Style="{StaticResource Badge}" Margin="0,8,0,0" HorizontalAlignment="Left">
                        <TextBlock Text="兼容版 v3.0" Foreground="#6EE7B7" FontSize="11"/>
                    </Border>
                    <TextBlock Text="将共享打印机相关策略恢复至安全默认值，输出安全扫描与变更报告（含日志）。" FontSize="12" Foreground="#A9B8CE" TextWrapping="Wrap" Margin="0,10,0,0" LineHeight="19"/>
                    <Button x:Name="BtnRestore" Style="{StaticResource RunBtn}" Background="{StaticResource AccGreen}" Content="运行脚本"/>
                </StackPanel>
            </Border>
        </UniformGrid>

        <!-- 状态栏 -->
        <Border Grid.Row="2" Background="#14243C" CornerRadius="12" BorderBrush="#26395A" BorderThickness="1" Padding="14,10" Margin="0,16,0,0">
            <Grid>
                <Grid.ColumnDefinitions>
                    <ColumnDefinition Width="*"/>
                    <ColumnDefinition Width="Auto"/>
                    <ColumnDefinition Width="Auto"/>
                </Grid.ColumnDefinitions>
                <TextBlock x:Name="StatusText" Text="就绪 — 点击上方卡片运行对应脚本（会弹出管理员授权）" Foreground="#A9B8CE" FontSize="12.5" VerticalAlignment="Center" TextTrimming="CharacterEllipsis"/>
                <Button Grid.Column="1" x:Name="ViewLogBtn" Style="{StaticResource GhostBtn}" Content="查看日志" IsEnabled="False"/>
                <Button Grid.Column="2" x:Name="OpenScriptsBtn" Style="{StaticResource GhostBtn}" Content="打开脚本目录"/>
            </Grid>
        </Border>

        <!-- 运行记录 -->
        <DockPanel Grid.Row="3" Margin="0,14,0,0">
            <TextBlock DockPanel.Dock="Top" Text="运行记录" Foreground="#7DD3FC" FontSize="13" FontWeight="SemiBold" Margin="0,0,0,6"/>
            <ListBox x:Name="HistoryList" Background="#101E33" BorderBrush="#223452" BorderThickness="1" Foreground="#C6D3E6" FontSize="12" ScrollViewer.HorizontalScrollBarVisibility="Disabled">
                <ListBox.ItemContainerStyle>
                    <Style TargetType="ListBoxItem">
                        <Setter Property="Padding" Value="6,3"/>
                        <Setter Property="HorizontalContentAlignment" Value="Stretch"/>
                        <Setter Property="Background" Value="Transparent"/>
                        <Setter Property="Focusable" Value="False"/>
                    </Style>
                </ListBox.ItemContainerStyle>
            </ListBox>
        </DockPanel>

        <!-- 底部说明 -->
        <TextBlock Grid.Row="4" Text="PrinterKeeper · 脚本以管理员身份在独立窗口交互运行 · 入口版本：兼容版 · ExecutionPolicy Bypass" FontSize="11" Foreground="#6E8099" HorizontalAlignment="Center" Margin="0,12,0,0"/>
    </Grid>
</Window>
'@

$reader = New-Object System.Xml.XmlNodeReader $xaml
try {
    $window = [Windows.Markup.XamlReader]::Load($reader)
} catch {
    [System.Windows.MessageBox]::Show("界面加载失败：$($_.Exception.Message)", 'PrinterKeeper', 'OK', 'Error') | Out-Null
    exit 1
}

# ---------- 控件引用 ----------
$StatusText      = $window.FindName('StatusText')
$HistoryList     = $window.FindName('HistoryList')
$ViewLogBtn      = $window.FindName('ViewLogBtn')
$OpenScriptsBtn  = $window.FindName('OpenScriptsBtn')
$BtnConnect      = $window.FindName('BtnConnect')
$BtnPerm         = $window.FindName('BtnPerm')
$BtnRestore      = $window.FindName('BtnRestore')

# ---------- 状态与历史 ----------
$script:History      = New-Object System.Collections.ArrayList
$script:lastLog      = $null
$script:watchPattern = $null
$script:watchStart   = $null
$script:watchName    = $null
$script:watchExact   = $null
$script:watchDeadline= $null

function Show-Status {
    param([string]$Text, [string]$Color = 'Default')
    $map = @{ 'Red'='#F87171'; 'Green'='#4ADE80'; 'Sky'='#7DD3FC'; 'Default'='#A9B8CE' }
    $StatusText.Text = $Text
    $StatusText.Foreground = New-Object Windows.Media.SolidColorBrush ([Windows.Media.ColorConverter]::ConvertFromString($map[$Color]))
}

function Add-History {
    param([string]$Message)
    $null = $script:History.Add("[$(Get-Date -Format 'HH:mm:ss')] $Message")
    $HistoryList.ItemsSource = $null
    $HistoryList.ItemsSource = $script:History
    $HistoryList.ScrollIntoView($script:History[$script:History.Count - 1])
}

# 日志监视：连接/权限脚本以「桌面日志生成」作为完成信号；还原脚本以「日志写入完成标记」作为完成信号
function Watch-Logs {
    $done = $false
    $logPath = $null
    if ($script:watchExact) {
        if ((Test-Path $script:watchExact) -and ((Get-Content -Path $script:watchExact -Raw -ErrorAction SilentlyContinue) -match '脚本执行完毕')) {
            $done = $true
            $logPath = $script:watchExact
        }
    } else {
        $desktop = [Environment]::GetFolderPath('Desktop')
        $candidates = @(Get-ChildItem -Path $desktop -Filter $script:watchPattern -File -ErrorAction SilentlyContinue |
            Where-Object { $_.LastWriteTime -ge $script:watchStart })
        if ($candidates.Count -gt 0) {
            $latest = $candidates | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            $done = $true
            $logPath = $latest.FullName
        }
    }
    if ($done) {
        $timer.Stop()
        $script:lastLog = $logPath
        $ViewLogBtn.IsEnabled = $true
        Add-History "「$($script:watchName)」执行完毕，日志已生成"
        Show-Status "「$($script:watchName)」执行完毕，日志: $([System.IO.Path]::GetFileName($logPath))" -Color 'Green'
        return
    }
    if ($script:watchDeadline -and (Get-Date) -gt $script:watchDeadline) {
        $timer.Stop()
        Show-Status "等待「$($script:watchName)」超时，请检查已打开的脚本窗口" -Color 'Red'
    }
}

function Launch-Script {
    param([string]$Name, [string]$Version, [string]$Path, [string]$Pattern, [switch]$Confirm, [string]$ExplicitLog)
    if (-not (Test-Path $Path)) {
        Show-Status "脚本不存在：$Path" -Color 'Red'
        Add-History "错误：找不到脚本 $Path"
        return
    }
    if ($Confirm) {
        $r = [System.Windows.MessageBox]::Show(
            "「$Name」将修改系统策略 / 注册表 / 服务设置，确定运行？`n`n运行完成后建议用「系统还原」恢复安全默认。",
            'PrinterKeeper', 'YesNo', 'Warning')
        if ($r -ne 'Yes') { return }
    }
    $argList = @('-NoExit', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', "`"$Path`"")
    if ($ExplicitLog) { $argList += '-LogPath'; $argList += "`"$ExplicitLog`"" }
    try {
        Start-Process -FilePath 'powershell.exe' -ArgumentList $argList -Verb RunAs
        Add-History "已启动「$Name」（$Version），管理员窗口已打开"
        $script:watchExact   = $null
        $script:watchPattern = $null
        $script:watchStart   = (Get-Date).AddSeconds(-10)
        $script:watchName    = $Name
        $script:watchDeadline = (Get-Date).AddMinutes(10)
        if ($ExplicitLog) { $script:watchExact = $ExplicitLog } else { $script:watchPattern = $Pattern }
        $timer.Start()
        Show-Status "「$Name」已启动（管理员窗口），等待完成..." -Color 'Sky'
    } catch {
        Add-History "启动「$Name」失败（可能取消了管理员授权）"
        Show-Status "启动失败：$($_.Exception.Message)" -Color 'Red'
    }
}

# ---------- 事件绑定 ----------
$BtnConnect.Add_Click({
    Launch-Script -Name '连接打印机' -Version '兼容版 v4.0' -Path $connectPath -Pattern 'PrinterConnect-*.log'
})
$BtnPerm.Add_Click({
    Launch-Script -Name '权限修复' -Version '兼容版 v2.5' -Path $permPath -Pattern 'PrinterPermissions-*.log' -Confirm
})
$BtnRestore.Add_Click({
    $log = Join-Path ([Environment]::GetFolderPath('Desktop')) "PrinterRestore-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
    Launch-Script -Name '系统还原' -Version '兼容版 v3.0' -Path $restorePath -Confirm -ExplicitLog $log
})
$ViewLogBtn.Add_Click({
    if ($script:lastLog -and (Test-Path $script:lastLog)) {
        Start-Process -FilePath 'notepad.exe' -ArgumentList "`"$($script:lastLog)`""
    }
})
$OpenScriptsBtn.Add_Click({ Start-Process explorer.exe $compatDir })

# ---------- 日志监视器 ----------
$timer = New-Object System.Windows.Threading.DispatcherTimer
$timer.Interval = [TimeSpan]::FromSeconds(2)
$timer.Add_Tick({ Watch-Logs })

Add-History "工具箱已启动（入口：兼容版）"
Add-History "脚本目录：$compatDir"
foreach ($item in @(@('连接打印机', $connectPath), @('权限修复', $permPath), @('系统还原', $restorePath))) {
    if (Test-Path $item[1]) { Add-History "就绪：$($item[0]) 脚本已找到" }
    else { Add-History "警告：$($item[0]) 脚本缺失（$($item[1])）" }
}

$window.ShowDialog() | Out-Null
