﻿<#
.SYNOPSIS
    打印机权限修复工具（跨 Win10/11 兼容版 v2.5）
.DESCRIPTION
    自动修复系统策略、服务、防火墙等，为网络打印机（含旧式）连接做好准备。
    已修复：PowerShell 5.1 兼容、来宾账户检测不依赖系统语言、遍历全部网络、
    统一防火墙规则命名、控制台进度输出。
.NOTES
    版本: 2.5 (兼容 Win10/11 全系，PowerShell 5.1+)
    需以管理员身份运行
#>
[CmdletBinding()]
param(
    [switch]$EnableSMB1Feature,   # 额外通过 DISM 安装 SMB1 功能（旧式打印机需要）
    [switch]$SkipRebootPrompt
)
$ErrorActionPreference = 'Continue'
$LogFile = Join-Path $env:TEMP "PrinterPermissions-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
$DesktopLog = Join-Path ([Environment]::GetFolderPath('Desktop')) "PrinterPermissions-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
$NeedReboot = $false
# 统一防火墙规则名（与还原脚本保持一致）
$FirewallRuleName = "网络打印机授权-共享放行规则"

function Write-Log {
    param([string]$Message, [ValidateSet('Info','Success','Warning','Error','Fix')][string]$Level='Info')
    $logLine = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [$Level] $Message"
    Add-Content -Path $LogFile -Value $logLine
    switch ($Level) {
        'Info'    { Write-Host "   [INFO] $Message" -ForegroundColor Cyan }
        'Success' { Write-Host "   [OK]   $Message" -ForegroundColor Green }
        'Warning' { Write-Host "   [WARN] $Message" -ForegroundColor Yellow }
        'Error'   { Write-Host "   [ERR]  $Message" -ForegroundColor Red }
        'Fix'     { Write-Host "   [FIX]  $Message" -ForegroundColor Magenta }
    }
}
function Show-Title { param([string]$Text) Write-Host "`n>>> $Text" -ForegroundColor White -BackgroundColor DarkBlue }

# 管理员检查
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ERR] 需要管理员权限运行。" -ForegroundColor Red
    exit 1
}

Clear-Host
Write-Host "Printer Permission Repair v2.5 (Win10/11 compatible)" -ForegroundColor Cyan
Write-Log "权限修复开始"

function Set-RegValueWithVerification {
    param([string]$Path, [string]$Name, [int]$Value, [string]$Description, [bool]$CreateIfMissing=$true)
    # 返回 $true 仅表示"本次实际修改了注册表值"；值原本已正确或修复失败时返回 $false
    try {
        if (-not (Test-Path $Path)) {
            if ($CreateIfMissing) { New-Item -Path $Path -Force | Out-Null }
            else { Write-Log "$Description 路径缺失" -Level Warning; return $false }
        }
        $current = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name
        if ($null -eq $current) { Write-Log "$Description 未设置" -Level Info }
        elseif ($current -eq $Value) { Write-Log "$Description 已正确" -Level Success; return $false }
        else { Write-Log "$Description 需要修改 ($current -> $Value)" -Level Info }

        Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type DWord -Force
        Start-Sleep -Milliseconds 200
        $newValue = (Get-ItemProperty -Path $Path -Name $Name -ErrorAction SilentlyContinue).$Name
        if ($newValue -eq $Value) { Write-Log "$Description 已修复" -Level Fix; return $true }
        else { Write-Log "$Description 修复失败" -Level Error; return $false }
    } catch { Write-Log "$Description 错误: $_" -Level Error; return $false }
}

# ---------- 来宾账户（不依赖系统语言）----------
function Get-GuestEnabled {
    try {
        $g = Get-LocalUser -Name Guest -ErrorAction Stop
        return [bool]$g.Enabled
    } catch {
        # 旧系统回退：解析 net user 输出（中英文都兼容）
        $out = net user Guest 2>&1 | Out-String
        if ($out -match 'Account active\s+(Yes|是)') { return $true }
        if ($out -match 'Account active\s+(No|否)') { return $false }
        if ($out -match '(Yes|是)\s*$') { return $true }
        return $false
    }
}
function Set-GuestEnabled {
    param([bool]$Enable)
    try {
        if ($Enable) { Enable-LocalUser -Name Guest -ErrorAction Stop }
        else { Disable-LocalUser -Name Guest -ErrorAction Stop }
        return $true
    } catch {
        if ($Enable) { net user Guest /active:yes 2>$null | Out-Null }
        else { net user Guest /active:no 2>$null | Out-Null }
        return ($LASTEXITCODE -eq 0)
    }
}

Show-Title "修复系统设置..."

# 1. 网络访问模型（经典模式）
Set-RegValueWithVerification -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "forceguest" -Value 0 -Description "网络访问模型"

# 2. 来宾账户启用
if (Get-GuestEnabled) { Write-Log "来宾账户已启用" -Level Success }
else {
    Set-GuestEnabled $true
    if (Get-GuestEnabled) { Write-Log "来宾账户已启用" -Level Fix }
    else { Write-Log "来宾账户启用失败" -Level Warning }
}

# 3. SMB 1.0 协议（旧式打印机需要）
$smbChanged = Set-RegValueWithVerification -Path "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters" -Name "SMB1" -Value 1 -Description "SMB 1.0"
if ($smbChanged) { $NeedReboot = $true }
if ($EnableSMB1Feature) {
    Write-Log "正在通过 DISM 安装 SMB1 功能..." -Level Info
    & dism /online /norestart /enable-feature /featurename:SMB1Protocol 2>$null | Out-Null
    if ($LASTEXITCODE -eq 0) { Write-Log "SMB1 功能已安装" -Level Fix; $NeedReboot = $true }
    else { Write-Log "SMB1 功能安装失败或需要重启后生效" -Level Warning }
}

# 4. 不安全来宾登录
Set-RegValueWithVerification -Path "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation" -Name "AllowInsecureGuestAuth" -Value 1 -Description "不安全来宾登录"

# 5. RPC 设置（旧式打印依赖命名管道）
try {
    $regRPC = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC"
    if (-not (Test-Path $regRPC)) { New-Item -Path $regRPC -Force | Out-Null }
    Set-ItemProperty -Path $regRPC -Name "RpcUseNamedPipeProtocol" -Value 1 -Type DWord -Force
    Set-ItemProperty -Path $regRPC -Name "RpcAuthenticationLevel" -Value 0 -Type DWord -Force
    $r1 = (Get-ItemProperty -Path $regRPC -Name "RpcUseNamedPipeProtocol").RpcUseNamedPipeProtocol
    $r2 = (Get-ItemProperty -Path $regRPC -Name "RpcAuthenticationLevel").RpcAuthenticationLevel
    if ($r1 -eq 1 -and $r2 -eq 0) { Write-Log "RPC 已优化" -Level Fix } else { Write-Log "RPC 优化失败" -Level Warning }
} catch { Write-Log "RPC 错误" -Level Warning }

# 6. 点和打印限制（旧式驱动安装需要）
Set-RegValueWithVerification -Path "HKLM:\Software\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "RestrictDriverInstallationToAdministrators" -Value 0 -Description "驱动安装限制"
Set-RegValueWithVerification -Path "HKLM:\Software\Policies\Microsoft\Windows NT\Printers\PointAndPrint" -Name "NoWarningNoElevationOnInstall" -Value 1 -Description "安装警告"

# 7. 令牌过滤策略（远程管理）
Set-RegValueWithVerification -Path "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\system" -Name "LocalAccountTokenFilterPolicy" -Value 1 -Description "令牌过滤策略"

# 8. 凭据存储
Set-RegValueWithVerification -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa" -Name "DisableDomainCreds" -Value 0 -Description "凭据存储"

# 9. 系统服务
$services = @(
    @{Name="Spooler"; D="打印后台服务"},
    @{Name="Server"; D="文件共享服务"},
    @{Name="Workstation"; D="网络客户端服务"},
    @{Name="FDResPub"; D="Function Discovery 资源发布"},
    @{Name="SSDPSRV"; D="SSDP 发现"},
    @{Name="upnphost"; D="UPnP 设备主机"}
)
foreach ($svc in $services) {
    try {
        $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
        if (-not $s) { Write-Log "服务不存在: $($svc.Name)" -Level Warning; continue }
        if ($s.Status -ne 'Running') {
            Start-Service -Name $svc.Name -ErrorAction SilentlyContinue
            Start-Sleep -Seconds 1
            $s2 = Get-Service -Name $svc.Name
            if ($s2.Status -eq 'Running') { Write-Log "$($svc.D) 已启动" -Level Fix } else { Write-Log "$($svc.D) 启动失败" -Level Warning }
        } else { Write-Log "$($svc.D) 运行中" -Level Success }
        if ($s.StartType -eq 'Disabled') {
            Set-Service -Name $svc.Name -StartupType Automatic -ErrorAction SilentlyContinue
            if ((Get-Service -Name $svc.Name).StartType -eq 'Automatic') { Write-Log "$($svc.D) 已设为自动" -Level Fix }
        }
    } catch { Write-Log "$($svc.D) 错误" -Level Warning }
}

# 10. 网络类别改为专用（遍历全部网络）
try {
    $nets = @(Get-NetConnectionProfile -ErrorAction Stop)
    if ($nets.Count -eq 0) { Write-Log "未找到网络配置文件" -Level Warning }
    foreach ($net in $nets) {
        if ($net.NetworkCategory -eq 'Private') { Write-Log "网络 '$($net.Name)' 已是专用" -Level Success }
        else {
            try {
                Set-NetConnectionProfile -InterfaceIndex $net.InterfaceIndex -NetworkCategory Private -ErrorAction Stop
                Write-Log "网络 '$($net.Name)' 已改为专用" -Level Fix
            } catch { Write-Log "网络 '$($net.Name)' 类别修改失败" -Level Warning }
        }
    }
} catch {
    Write-Log "Cmdlet 失败，尝试注册表方法..." -Level Warning
    try {
        $regNet = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles"
        Get-ChildItem $regNet -ErrorAction SilentlyContinue | ForEach-Object {
            $cat = (Get-ItemProperty $_.PSPath -Name Category -ErrorAction SilentlyContinue).Category
            if ($cat -ne 1) { Set-ItemProperty $_.PSPath -Name Category -Value 1 -Type DWord -Force }
        }
        Write-Log "网络类别已通过注册表修复" -Level Fix
    } catch { Write-Log "网络类别修复失败" -Level Warning }
}

# 11. 防火墙规则（统一命名，可被还原脚本清理）
try {
    $existing = Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue
    if ($existing) { Write-Log "防火墙放行规则已存在" -Level Success }
    else {
        New-NetFirewallRule -DisplayName $FirewallRuleName -Direction Inbound -Protocol TCP -LocalPort 445,139,135 -Action Allow -Enabled True -Profile Private,Domain -ErrorAction Stop | Out-Null
        Write-Log "防火墙放行规则已创建: $FirewallRuleName" -Level Fix
    }
} catch { Write-Log "防火墙规则创建失败: $_" -Level Warning }

# 12. 刷新组策略
Write-Log "刷新组策略..." -Level Info
& gpupdate /force 2>$null | Out-Null
if ($LASTEXITCODE -eq 0) { Write-Log "组策略已刷新" -Level Success } else { Write-Log "组策略刷新可能失败" -Level Warning }

# 重启提示
Write-Host ""
if ($NeedReboot -and -not $SkipRebootPrompt) {
    Write-Log "部分设置需要重启才能生效" -Level Warning
    $rb = Read-Host "是否立即重启? (y/n)"
    if ($rb -and $rb.ToLower() -in @('y', 'yes')) { Restart-Computer -Force }
    else { Write-Log "请稍后手动重启" -Level Info }
}

Write-Log "权限修复完成" -Level Success
Write-Host "  日志: $LogFile" -ForegroundColor Gray
Copy-Item $LogFile $DesktopLog -Force -ErrorAction SilentlyContinue
Write-Host "  桌面日志: $DesktopLog" -ForegroundColor Gray
