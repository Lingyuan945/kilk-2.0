﻿<#
.SYNOPSIS
    共享打印机策略开关 + 系统安全校验工具 v3.0（跨 Win10/11 兼容版）
.DESCRIPTION
    自动将系统共享打印机相关策略恢复至安全默认值，并输出变更报告。
    已修复：PowerShell 5.1 兼容（移除三元运算符）、来宾检测不依赖系统语言、
    统一防火墙规则清理、遍历全部网络配置文件。
.PARAMETER Action
    Enable（放宽，用于打印机连接）或 Disable（恢复安全默认）。默认 Disable。
.PARAMETER ScanOnly
    仅执行安全扫描，不修改任何配置。
.PARAMETER LogPath
    将控制台输出同时记录到指定日志文件。
.PARAMETER AutoFix
    预留兼容参数，无额外行为（脚本默认即自动执行安全加固）。如确认无外部调用，可安全删除。
.NOTES
    版本: 3.0 兼容版（PowerShell 5.1+，Windows 10 / 11）
    要求: 管理员权限
    制作者: IT-ling (信息技术部门)
#>
[CmdletBinding()]
param(
    [ValidateSet('Enable', 'Disable')][string]$Action,
    [switch]$ScanOnly,
    [switch]$AutoFix,       # 预留兼容参数（见 .PARAMETER 说明）
    [string]$LogPath
)

# 统一防火墙规则名（与权限修复脚本保持一致）
$FirewallRuleName = "网络打印机授权-共享放行规则"

$script:LogFile = $LogPath
$script:LogStream = $null
if ($LogPath) {
    try {
        $dir = Split-Path $LogPath -Parent
        if ($dir -and -not (Test-Path $dir)) { New-Item -Path $dir -ItemType Directory -Force | Out-Null }
        $script:LogStream = [System.IO.StreamWriter]::new($LogPath, $false, [System.Text.Encoding]::UTF8)
        $script:LogStream.AutoFlush = $true
    } catch {
        Write-Warning "无法创建日志文件，将仅输出到控制台。错误: $_"
        $script:LogStream = $null
    }
}

function Write-Log {
    param($Message, [string]$ForegroundColor = '')
    $time = Get-Date -Format 'yyyy-MM-dd HH:mm:ss'
    $line = "[$time] $Message"
    if ($ForegroundColor) { Write-Host $line -ForegroundColor $ForegroundColor }
    else { Write-Host $line }
    if ($script:LogStream) { $script:LogStream.WriteLine($line) }
}

function Write-Section {
    param($Title)
    Write-Log ""
    Write-Log ("=" * 60) -ForegroundColor Cyan
    Write-Log "  $Title" -ForegroundColor White
    Write-Log ("=" * 60) -ForegroundColor Cyan
}

# 管理员检查
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Log "[ERR] 需要管理员权限运行。" -ForegroundColor Red
    if ($script:LogStream) { $script:LogStream.Close() }
    exit 1
}

# 常量
$REG_LSA = "HKLM:\SYSTEM\CurrentControlSet\Control\Lsa"
$REG_SMB1 = "HKLM:\SYSTEM\CurrentControlSet\Services\LanmanServer\Parameters"
$REG_UNC = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\LanmanWorkstation"
$REG_RPC = "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Printers\RPC"
$REG_PP = "HKLM:\Software\Policies\Microsoft\Windows NT\Printers\PointAndPrint"
$REG_SYS = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\system"
$REG_NET_PROFILES = "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\NetworkList\Profiles"

# ---------- 来宾账户检测（不依赖系统语言）----------
function Get-GuestEnabled {
    try {
        $g = Get-LocalUser -Name Guest -ErrorAction Stop
        return [bool]$g.Enabled
    } catch {
        $out = net user Guest 2>&1 | Out-String
        if ($out -match 'Account active\s+(Yes|是)') { return $true }
        if ($out -match 'Account active\s+(No|否)') { return $false }
        if ($out -match '(Yes|是)\s*$') { return $true }
        return $false
    }
}

# ============================================================
# 安全扫描
# ============================================================
function Invoke-SecurityScan {
    param([switch]$ReturnResults)
    # 结果存入脚本作用域：嵌套函数内 $script: 前缀的修改才能回传（普通 $results += 只改局部变量，会导致结果恒为空）
    $script:ScanResults = @()
    $riskCount = @{ High=0; Medium=0; Low=0; Info=0 }

    function Add-Result {
        param($Name, $Value, $Expected, $Risk, $Suggestion, [switch]$NoOutput)
        $valStr = if ($null -eq $Value) { "未设置" } else { $Value.ToString() }
        $expStr = if ($null -eq $Expected) { "未设置" } else { $Expected.ToString() }
        $color = switch ($Risk) {
            'High'   { 'Red' }
            'Medium' { 'Yellow' }
            'Low'    { 'Gray' }
            'Info'   { 'Cyan' }
            default  { 'White' }
        }
        $status = if ($valStr -eq $expStr) { "[合规] $Name" } else { "[不合规] $Name" }
        $riskLabel = switch ($Risk) { 'High' {'高'} 'Medium' {'中'} 'Low' {'低'} 'Info' {'信息'} }

        if (-not $NoOutput) {
            Write-Log "   $status" -ForegroundColor White
            Write-Log "     当前值: $valStr" -ForegroundColor Gray
            Write-Log "     期望值: $expStr" -ForegroundColor Gray
            Write-Log "     风险等级: $riskLabel" -ForegroundColor $color
            Write-Log "     建议: $Suggestion" -ForegroundColor Gray
            Write-Log ""
        }
        if ($Risk -eq 'High')   { $riskCount.High++ }
        if ($Risk -eq 'Medium') { $riskCount.Medium++ }
        if ($Risk -eq 'Low')    { $riskCount.Low++ }
        if ($Risk -eq 'Info')   { $riskCount.Info++ }

        $script:ScanResults += [PSCustomObject]@{
            Name = $Name; Value = $valStr; Expected = $expStr; Risk = $Risk
            Suggestion = $Suggestion; IsCompliant = ($valStr -eq $expStr)
        }
    }

    # 1. SMB1
    try {
        $smb1 = (Get-ItemProperty -Path $REG_SMB1 -Name "SMB1" -ErrorAction SilentlyContinue).SMB1
        if ($null -eq $smb1) { $smb1 = 0 }
        if ($smb1 -eq 1) { $smbStr = "启用" } else { $smbStr = "禁用" }
        Add-Result -Name "SMB 1.0 协议" -Value $smbStr -Expected "禁用" -Risk "High" `
            -Suggestion "SMB1 存在严重安全漏洞，应始终禁用（除非旧式打印机必需）" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取 SMB1 设置: $_" -ForegroundColor Red }

    # 2. 来宾账户
    try {
        $gStatus = if (Get-GuestEnabled) { "启用" } else { "禁用" }
        Add-Result -Name "来宾账户 (Guest)" -Value $gStatus -Expected "禁用" -Risk "Medium" `
            -Suggestion "来宾账户通常应禁用，防止未经授权的访问" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取来宾账户状态: $_" -ForegroundColor Red }

    # 3. forceguest
    try {
        $fg = (Get-ItemProperty -Path $REG_LSA -Name "forceguest" -ErrorAction SilentlyContinue).forceguest
        if ($null -eq $fg) { $fg = 1 }
        if ($fg -eq 0) { $fgStr = "经典模式" } else { $fgStr = "仅来宾模式" }
        Add-Result -Name "网络访问模型 (forceguest)" -Value $fgStr -Expected "仅来宾模式 (1)" -Risk "Medium" `
            -Suggestion "经典模式（0）允许使用具体账户，可能增加暴露风险" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取 forceguest: $_" -ForegroundColor Red }

    # 4. AllowInsecureGuestAuth
    try {
        $insecure = (Get-ItemProperty -Path $REG_UNC -Name "AllowInsecureGuestAuth" -ErrorAction SilentlyContinue).AllowInsecureGuestAuth
        if ($null -eq $insecure) { $insecure = 0 }
        if ($insecure -eq 1) { $insecureStr = "允许" } else { $insecureStr = "禁止" }
        Add-Result -Name "不安全来宾登录" -Value $insecureStr -Expected "禁止 (0)" -Risk "Medium" `
            -Suggestion "允许不安全来宾登录可能导致网络嗅探攻击" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取 AllowInsecureGuestAuth: $_" -ForegroundColor Red }

    # 5. LocalAccountTokenFilterPolicy
    try {
        $token = (Get-ItemProperty -Path $REG_SYS -Name "LocalAccountTokenFilterPolicy" -ErrorAction SilentlyContinue).LocalAccountTokenFilterPolicy
        if ($null -eq $token) { $token = 0 }
        if ($token -eq 1) { $tokenStr = "启用" } else { $tokenStr = "禁用" }
        Add-Result -Name "远程管理员令牌过滤" -Value $tokenStr -Expected "禁用 (0)" -Risk "Medium" `
            -Suggestion "启用（1）允许远程管理员完全控制，增加风险" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取令牌过滤: $_" -ForegroundColor Red }

    # 6. 点和打印限制
    try {
        $restrict = (Get-ItemProperty -Path $REG_PP -Name "RestrictDriverInstallationToAdministrators" -ErrorAction SilentlyContinue).RestrictDriverInstallationToAdministrators
        $noWarn   = (Get-ItemProperty -Path $REG_PP -Name "NoWarningNoElevationOnInstall" -ErrorAction SilentlyContinue).NoWarningNoElevationOnInstall
        if ($null -eq $restrict) { $restrict = 1 }
        if ($null -eq $noWarn)   { $noWarn = 0 }
        $ppStr = "Restrict=$restrict, NoWarn=$noWarn"
        Add-Result -Name "点和打印限制" -Value $ppStr -Expected "Restrict=1, NoWarn=0" -Risk "Medium" `
            -Suggestion "推荐 Restrict=1（管理员安装），NoWarn=0（显示警告）" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取点和打印限制: $_" -ForegroundColor Red }

    # 7. RPC 打印机策略（信息项）
    try {
        $rpc1 = (Get-ItemProperty -Path $REG_RPC -Name "RpcUseNamedPipeProtocol" -ErrorAction SilentlyContinue).RpcUseNamedPipeProtocol
        $rpc2 = (Get-ItemProperty -Path $REG_RPC -Name "RpcAuthenticationLevel" -ErrorAction SilentlyContinue).RpcAuthenticationLevel
        if ($null -eq $rpc1 -and $null -eq $rpc2) { $rpcStr = "未配置（默认）" } else { $rpcStr = "RpcUseNamedPipeProtocol=$rpc1, RpcAuth=$rpc2" }
        Add-Result -Name "RPC 打印机策略" -Value $rpcStr -Expected "未配置（默认）" -Risk "Info" `
            -Suggestion "默认通常足够，不建议修改" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取 RPC 设置: $_" -ForegroundColor Red }

    # 8. 防火墙自定义规则（信息项）
    try {
        $fwRule = Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue
        $fwStr = if ($fwRule) { "存在" } else { "不存在" }
        Add-Result -Name "自定义防火墙放行规则" -Value $fwStr -Expected "不存在" -Risk "Info" `
            -Suggestion "连接完成后应删除该放行规则（还原脚本将自动处理）" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取防火墙规则: $_" -ForegroundColor Red }

    # 9. 网络类别
    try {
        $nets = @(Get-NetConnectionProfile -ErrorAction Stop)
        $categories = ($nets | ForEach-Object { $_.NetworkCategory }) -join ', '
        Add-Result -Name "网络类别" -Value $categories -Expected "Public" -Risk "Medium" `
            -Suggestion "公共网络（Public）更安全；专用（Private）适合信任环境。当前为 $categories" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取网络类别: $_" -ForegroundColor Red }

    # 10. 关键服务
    $svcList = @(
        @{Name="Spooler"; Display="打印后台"},
        @{Name="Server"; Display="文件共享"},
        @{Name="Workstation"; Display="网络客户端"}
    )
    foreach ($svc in $svcList) {
        try {
            $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
            if (-not $s) {
                Add-Result -Name "服务: $($svc.Name)" -Value "未安装" -Expected "Running / Automatic" -Risk "Info" `
                    -Suggestion "服务不存在，可能无需关注" -NoOutput:$ReturnResults
                continue
            }
            $status = "$($s.Status) / $($s.StartType)"
            Add-Result -Name "服务: $($svc.Name)" -Value $status -Expected "Running / Automatic" -Risk "Info" `
                -Suggestion "关键服务应运行并设为自动启动" -NoOutput:$ReturnResults
        } catch { Write-Log "   无法检查服务 $($svc.Name): $_" -ForegroundColor Red }
    }

    # 11. UAC
    try {
        $uac = (Get-ItemProperty -Path $REG_SYS -Name "EnableLUA" -ErrorAction SilentlyContinue).EnableLUA
        if ($null -eq $uac) { $uac = 1 }
        if ($uac -eq 1) { $uacStr = "启用" } else { $uacStr = "禁用" }
        Add-Result -Name "UAC (用户账户控制)" -Value $uacStr -Expected "启用 (1)" -Risk "High" `
            -Suggestion "UAC 必须启用，否则系统易受恶意软件攻击" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取 UAC: $_" -ForegroundColor Red }

    # 12. 远程桌面
    try {
        $rdp = (Get-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\Terminal Server" -Name "fDenyTSConnections" -ErrorAction SilentlyContinue).fDenyTSConnections
        if ($null -eq $rdp) { $rdp = 1 }
        if ($rdp -eq 0) { $rdpStr = "启用" } else { $rdpStr = "禁用" }
        Add-Result -Name "远程桌面" -Value $rdpStr -Expected "禁用 (1)" -Risk "Medium" `
            -Suggestion "除非必要，否则应禁用远程桌面" -NoOutput:$ReturnResults
    } catch { Write-Log "   无法读取远程桌面: $_" -ForegroundColor Red }

    if ($ReturnResults) { return $script:ScanResults }

    Write-Log ""
    Write-Log "安全风险汇总:" -ForegroundColor Cyan
    Write-Log "  高 风险项: $($riskCount.High)" -ForegroundColor Red
    Write-Log "  中 风险项: $($riskCount.Medium)" -ForegroundColor Yellow
    Write-Log "  低 风险项: $($riskCount.Low)" -ForegroundColor Gray
    Write-Log "  信息项: $($riskCount.Info)" -ForegroundColor Cyan
}

# ============================================================
# 策略修改
# ============================================================
function Set-Policy {
    param($Mode)  # "Enable" or "Disable"
    Write-Section "执行策略修改 (模式: $Mode)"

    function Set-Reg {
        param($Path, $Name, $Value, $Type = 'DWord')
        try {
            if (-not (Test-Path $Path)) { New-Item -Path $Path -Force | Out-Null }
            Set-ItemProperty -Path $Path -Name $Name -Value $Value -Type $Type -Force -ErrorAction Stop
        } catch { Write-Log "   设置注册表失败: $Path\$Name = $Value ($_)" -ForegroundColor Yellow }
    }

    # 网络访问模型
    if ($Mode -eq 'Enable') { Set-Reg -Path $REG_LSA -Name "forceguest" -Value 0 }
    else { Set-Reg -Path $REG_LSA -Name "forceguest" -Value 1 }
    Write-Log "   • forceguest → $(if ($Mode -eq 'Enable') {'0 经典'} else {'1 仅来宾'})" -ForegroundColor Gray

    # 来宾账户
    if ($Mode -eq 'Enable') { net user Guest /active:yes 2>&1 | Out-Null }
    else { net user Guest /active:no 2>&1 | Out-Null }
    Write-Log "   • 来宾账户 → $(if ($Mode -eq 'Enable') {'启用'} else {'禁用'})" -ForegroundColor Gray

    # SMB1
    if ($Mode -eq 'Enable') { Set-Reg -Path $REG_SMB1 -Name "SMB1" -Value 1 }
    else { Set-Reg -Path $REG_SMB1 -Name "SMB1" -Value 0 }
    Write-Log "   • SMB1 → $(if ($Mode -eq 'Enable') {'1 启用'} else {'0 禁用'})" -ForegroundColor Gray

    # 不安全来宾登录
    if ($Mode -eq 'Enable') { Set-Reg -Path $REG_UNC -Name "AllowInsecureGuestAuth" -Value 1 }
    else { Set-Reg -Path $REG_UNC -Name "AllowInsecureGuestAuth" -Value 0 }
    Write-Log "   • AllowInsecureGuestAuth → $(if ($Mode -eq 'Enable') {'1'} else {'0'})" -ForegroundColor Gray

    # RPC 设置
    if ($Mode -eq 'Enable') {
        Set-Reg -Path $REG_RPC -Name "RpcUseNamedPipeProtocol" -Value 1
        Set-Reg -Path $REG_RPC -Name "RpcAuthenticationLevel" -Value 0
        Write-Log "   • RPC 设置 → 已配置" -ForegroundColor Gray
    } else {
        if (Test-Path $REG_RPC) {
            Remove-Item -Path $REG_RPC -Recurse -Force -ErrorAction SilentlyContinue
            Write-Log "   • RPC 设置 → 已移除（恢复默认）" -ForegroundColor Gray
        } else { Write-Log "   • RPC 设置 → 默认状态" -ForegroundColor Gray }
    }

    # 点和打印限制
    if ($Mode -eq 'Enable') {
        Set-Reg -Path $REG_PP -Name "RestrictDriverInstallationToAdministrators" -Value 0
        Set-Reg -Path $REG_PP -Name "NoWarningNoElevationOnInstall" -Value 1
        Write-Log "   • 点和打印限制 → 已放宽" -ForegroundColor Gray
    } else {
        Set-Reg -Path $REG_PP -Name "RestrictDriverInstallationToAdministrators" -Value 1
        Set-Reg -Path $REG_PP -Name "NoWarningNoElevationOnInstall" -Value 0
        Write-Log "   • 点和打印限制 → 已恢复（安全）" -ForegroundColor Gray
    }

    # LocalAccountTokenFilterPolicy
    if ($Mode -eq 'Enable') { Set-Reg -Path $REG_SYS -Name "LocalAccountTokenFilterPolicy" -Value 1 }
    else { Set-Reg -Path $REG_SYS -Name "LocalAccountTokenFilterPolicy" -Value 0 }
    Write-Log "   • LocalAccountTokenFilterPolicy → $(if ($Mode -eq 'Enable') {'1'} else {'0'})" -ForegroundColor Gray

    # DisableDomainCreds
    if ($Mode -eq 'Enable') { Set-Reg -Path $REG_LSA -Name "DisableDomainCreds" -Value 0 }
    else { Set-Reg -Path $REG_LSA -Name "DisableDomainCreds" -Value 1 }
    Write-Log "   • DisableDomainCreds → $(if ($Mode -eq 'Enable') {'0'} else {'1'})" -ForegroundColor Gray

    # 关键服务
    $services = @(
        @{Name="Spooler"; Display="打印后台"},
        @{Name="Server"; Display="文件共享"},
        @{Name="Workstation"; Display="网络客户端"}
    )
    foreach ($svc in $services) {
        try {
            $s = Get-Service -Name $svc.Name -ErrorAction SilentlyContinue
            if (-not $s) { continue }
            if ($Mode -eq 'Enable') {
                if ($s.Status -ne 'Running') { Start-Service -Name $svc.Name -ErrorAction SilentlyContinue }
                if ($s.StartType -ne 'Automatic') { Set-Service -Name $svc.Name -StartupType Automatic -ErrorAction SilentlyContinue }
            } else {
                if ($s.StartType -eq 'Disabled') { Set-Service -Name $svc.Name -StartupType Automatic -ErrorAction SilentlyContinue }
            }
        } catch { Write-Log "   处理服务 $($svc.Name) 出错: $_" -ForegroundColor Yellow }
    }
    Write-Log "   • 关键服务 → 已确保自动启动" -ForegroundColor Gray

    # 网络类别（遍历全部）
    try {
        $nets = @(Get-NetConnectionProfile -ErrorAction Stop)
        if ($Mode -eq 'Enable') { $cat = 'Private' } else { $cat = 'Public' }
        foreach ($net in $nets) {
            Set-NetConnectionProfile -InterfaceIndex $net.InterfaceIndex -NetworkCategory $cat -ErrorAction Stop
            Write-Log "   • 网络 '$($net.Name)' → $cat" -ForegroundColor Gray
        }
    } catch {
        Write-Log "   命令设置网络类别失败，尝试注册表..." -ForegroundColor Yellow
        try {
            if ($Mode -eq 'Enable') { $catVal = 1 } else { $catVal = 0 }
            Get-ChildItem -Path $REG_NET_PROFILES -ErrorAction SilentlyContinue | ForEach-Object {
                Set-ItemProperty -Path $_.PSPath -Name "Category" -Value $catVal -Type DWord -Force -ErrorAction SilentlyContinue
            }
            Write-Log "   • 网络类别（注册表）→ $catVal" -ForegroundColor Gray
        } catch { Write-Log "   无法修改网络类别: $_" -ForegroundColor Red }
    }

    # 防火墙规则（统一命名）
    if ($Mode -eq 'Enable') {
        try {
            $existing = Get-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue
            if (-not $existing) {
                New-NetFirewallRule -DisplayName $FirewallRuleName -Direction Inbound -Protocol TCP -LocalPort 445,139,135 -Action Allow -Enabled True -Profile Private,Domain -ErrorAction Stop | Out-Null
            }
            Write-Log "   • 防火墙 → 已添加放行规则" -ForegroundColor Gray
        } catch { Write-Log "   添加防火墙规则失败: $_" -ForegroundColor Yellow }
    } else {
        Remove-NetFirewallRule -DisplayName $FirewallRuleName -ErrorAction SilentlyContinue
        Write-Log "   • 防火墙 → 已删除放行规则" -ForegroundColor Gray
    }

    Write-Log "   • 正在刷新组策略..." -ForegroundColor Gray
    & gpupdate /force 2>&1 | Out-Null
    Write-Log "   • 组策略已刷新" -ForegroundColor Gray
    Write-Log ""
    Write-Log "策略修改完成！" -ForegroundColor Green
}

# ============================================================
# 主流程
# ============================================================
Clear-Host
Write-Log "╔══════════════════════════════════════════╗" -ForegroundColor Cyan
Write-Log "║  共享打印机策略开关 + 安全校验工具 v3.0 ║" -ForegroundColor Cyan
Write-Log "║          (兼容 Win10/11 全系)             ║" -ForegroundColor Cyan
Write-Log "╚══════════════════════════════════════════╝" -ForegroundColor Cyan

if ($ScanOnly) {
    Write-Log "`n[仅扫描模式]（不修改任何配置）" -ForegroundColor Yellow
    Invoke-SecurityScan
    if ($script:LogStream) { $script:LogStream.Close() }
    exit 0
}

if (-not $Action) { $mode = 'Disable' }   # 默认安全加固
else { $mode = $Action }

if ($mode -eq 'Enable') { $modeLabel = "放宽策略（启用修复）" }
else { $modeLabel = "安全加固（恢复默认）" }
Write-Log "`n[执行模式] $modeLabel" -ForegroundColor Cyan

Write-Log "`n[采集当前状态]..." -ForegroundColor Gray
$before = Invoke-SecurityScan -ReturnResults

Set-Policy -Mode $mode

Write-Log "`n[扫描变更后状态]..." -ForegroundColor Gray
$after = Invoke-SecurityScan -ReturnResults

# 变更报告
Write-Section "变更报告"
$changedItems = @()
for ($i=0; $i -lt $before.Count; $i++) {
    if ($before[$i].Value -ne $after[$i].Value) {
        $changedItems += [PSCustomObject]@{
            Name = $before[$i].Name
            Before = $before[$i].Value
            After = $after[$i].Value
        }
    }
}
if ($changedItems.Count -eq 0) {
    Write-Log "所有设置项均已符合安全基线，无变更。" -ForegroundColor Green
} else {
    Write-Log "以下设置项已变更:" -ForegroundColor Yellow
    foreach ($item in $changedItems) {
        Write-Log "  • $($item.Name)" -ForegroundColor White
        Write-Log "    原值: $($item.Before) → 新值: $($item.After)" -ForegroundColor Gray
    }
    Write-Log "总计 $($changedItems.Count) 项变更。" -ForegroundColor Cyan
}

Write-Section "执行结论"
if ($mode -eq 'Disable') {
    Write-Log "已成功将共享打印机相关策略恢复至安全默认状态。" -ForegroundColor Green
    Write-Log "如需重新放宽（用于连接打印机），请运行: .\脚本 -Action Enable" -ForegroundColor Cyan
} else {
    Write-Log "已成功启用共享打印机修复策略（放宽模式）。" -ForegroundColor Green
    Write-Log "如需恢复安全默认，请运行: .\脚本 -Action Disable" -ForegroundColor Cyan
}
if ($LogPath) { Write-Log "完整日志已保存至: $LogPath" -ForegroundColor Gray }

Write-Log "`n脚本执行完毕。" -ForegroundColor Cyan
if ($script:LogStream) { $script:LogStream.Close() }
