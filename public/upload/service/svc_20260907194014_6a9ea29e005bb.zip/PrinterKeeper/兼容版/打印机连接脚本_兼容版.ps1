﻿<#
.SYNOPSIS
    网络打印机连接工具（跨 Win10/11 兼容版 v4.0）
.DESCRIPTION
    自动连接共享打印机：支持自动发现共享、智能驱动选择、旧式打印机兼容
    （SMB1 检测、139 端口回退、TCP/IP 端口直连、通用驱动兜底、全用户安装）。
    已修复 PowerShell 5.1 兼容性、凭据清理、控制台进度输出等问题。
.NOTES
    版本: 4.0 (兼容 Win10/11 全系，PowerShell 5.1+)
    需以管理员身份运行
#>
[CmdletBinding()]
param(
    [ValidatePattern('^\d{1,3}(\.\d{1,3}){3}$')][string]$TargetIP,
    [string]$ComputerName,
    [string]$Username,
    [SecureString]$Password,
    [string]$ShareName,
    [switch]$KeepCredential
)
$ErrorActionPreference = 'Continue'
$LogFile = Join-Path $env:TEMP "PrinterConnect-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
$DesktopLog = Join-Path ([Environment]::GetFolderPath('Desktop')) "PrinterConnect-$(Get-Date -Format 'yyyyMMdd-HHmmss').log"
$Success = $false
$Method = ""
$UsedDriver = ""
$Connected = $false

function Write-Log {
    param([string]$Message, [ValidateSet('Info','Success','Warning','Error','Fix')][string]$Level='Info')
    $logLine = "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') [$Level] $Message"
    Add-Content -Path $LogFile -Value $logLine
    switch ($Level) {
        'Info'    { Write-Host "   [INFO] $Message" -ForegroundColor Cyan }
        'Success' { Write-Host "   [OK]   $Message" -ForegroundColor Green }
        'Warning' { Write-Host "   [WARN] $Message" -ForegroundColor Yellow }
        'Error'   { Write-Host "   [ERR]  $Message" -ForegroundColor Red }
        'Fix'     { Write-Host "   [FIX]  $Message" -ForegroundColor Magenta }
    }
}
function Show-Title { param([string]$Text) Write-Host "`n>>> $Text" -ForegroundColor White -BackgroundColor DarkBlue }

# 管理员检查
$principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Write-Host "[ERR] 需要管理员权限运行。" -ForegroundColor Red
    exit 1
}

Clear-Host
Write-Host "Network Printer Connection v4.0 (Win10/11 compatible)" -ForegroundColor Cyan
Write-Log "Connection script started"

# ---------- 参数收集 ----------
if (-not $TargetIP) { $TargetIP = Read-Host "`n打印机主机 IP 地址" }
if (-not $ComputerName) { $ComputerName = Read-Host "主机名 / 域名" }
if (-not $Username) { $Username = Read-Host "用户名" }
if (-not $Password) {
    do {
        $Password = Read-Host "密码" -AsSecureString
        if ($null -eq $Password -or $Password.Length -eq 0) { Write-Host "[ERR] 密码不能为空，请重新输入。" -ForegroundColor Red }
    } while ($null -eq $Password -or $Password.Length -eq 0)
}
if (-not $ShareName) { $ShareName = Read-Host "共享名（留空自动发现）" }

$FullUsername = "$ComputerName\$Username"
try {
    $Credential = New-Object System.Management.Automation.PSCredential($FullUsername, $Password)
} catch {
    Write-Host "[ERR] 凭据创建失败: $_" -ForegroundColor Red
    exit 1
}
Write-Log "目标: $TargetIP, 用户: $FullUsername"

# ---------- 凭据与连接 ----------
function Connect-ToRemoteHost {
    param([string]$HostName, [PSCredential]$Cred)
    # 注意: cmdkey/net use 机制只能在命令行以明文传密码（Windows 机制限制），密码会短暂出现在进程命令行中。
    # 脚本默认在退出时统一清理凭据；使用 -KeepCredential 时密码会持久化到凭据管理器，请自行评估风险。
    & cmdkey /delete:$HostName 2>$null | Out-Null
    $pass = $Cred.GetNetworkCredential().Password
    $user = $Cred.UserName
    $cmdkeyArgs = @("/add:$HostName", "/user:$user", "/pass:$pass")
    $output = & cmdkey @cmdkeyArgs 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Log "凭据存储失败: $output" -Level Error
        return $false
    }
    $null = net use "\\$HostName\IPC$" /persistent:no 2>$null
    if ($LASTEXITCODE -ne 0) {
        Write-Log "IPC$ 连接失败 (net use 退出码 $LASTEXITCODE)" -Level Error
        return $false
    }
    Write-Log "远程主机认证成功 (IPC$ 已连接)" -Level Success
    return $true
}

function Remove-Credential {
    param([string]$HostName)
    & cmdkey /delete:$HostName 2>$null | Out-Null
    net use "\\$HostName\IPC$" /delete 2>$null | Out-Null
    Write-Log "已清理临时凭据: $HostName" -Level Fix
}

# 统一退出：任何退出路径都先清理凭据并复制日志，避免残留 cmdkey 凭据
function Exit-Script {
    param([int]$Code)
    if (-not $KeepCredential) { Remove-Credential $TargetIP }
    Copy-Item $LogFile $DesktopLog -Force -ErrorAction SilentlyContinue
    exit $Code
}

# ---------- 连通性检查（含旧式 139 回退）----------
Show-Title "网络连通性检查"
$pingOk = Test-Connection $TargetIP -Count 2 -Quiet
if ($pingOk) {
    Write-Log "Ping 成功" -Level Success
} else {
    # 部分防火墙会拦截 ICMP 但允许 SMB，Ping 失败不作为最终判据，继续端口检查
    Write-Log "Ping 不通（可能被防火墙拦截 ICMP），继续端口检查..." -Level Warning
}

$t445 = Test-NetConnection $TargetIP -Port 445 -WarningAction SilentlyContinue
$t139 = $null
if ($t445.TcpTestSucceeded) {
    Write-Log "端口 445 (SMB) 开放" -Level Success
} else {
    Write-Log "端口 445 关闭，尝试旧式 139 端口..." -Level Warning
    $t139 = Test-NetConnection $TargetIP -Port 139 -WarningAction SilentlyContinue
    if ($t139.TcpTestSucceeded) {
        Write-Log "端口 139 开放（旧式 SMB1 共享打印机常见）" -Level Warning
        Write-Log "提示: 旧式打印机可能依赖 SMB1。若后续连接失败，请先运行「权限修复脚本」启用 SMB1。" -Level Info
    } else {
        Write-Log "端口 445/139 均不可达，目标可能未开放文件共享服务" -Level Error
        exit 2
    }
}

# ---------- 发现共享打印机 ----------
function Discover-Shares {
    Show-Title "发现共享打印机"
    if ($ShareName) { Write-Log "使用指定共享: $ShareName" -Level Info; return @($ShareName) }
    if (-not (Connect-ToRemoteHost $TargetIP $Credential)) { Write-Log "认证失败" -Level Error; return $null }

    $shares = @()
    try {
        $shares = @(Get-CimInstance Win32_Share -ComputerName $TargetIP -Filter "Type=1" -ErrorAction Stop | Select-Object -ExpandProperty Name)
        if ($shares.Count -eq 0) { Write-Log "未发现打印机共享" -Level Warning }
        else { Write-Log "发现 $($shares.Count) 个打印机共享 (CIM)" -Level Success }
    } catch {
        Write-Log "CIM 查询失败，尝试 net view 解析..." -Level Warning
        $raw = net view "\\$TargetIP" 2>$null
        $inList = $false
        foreach ($l in $raw) {
            if ($l -match '^-{10,}$') { $inList = $true; continue }
            if (-not $inList) { continue }
            if ($l -match "command completed successfully") { continue }
            $parts = $l -split '\s{2,}' | Where-Object { $_.Trim() }
            if ($parts.Count -ge 2 -and $parts[1] -match 'Print|打印') { $shares += $parts[0].Trim() }
        }
    }

    if ($shares.Count -eq 0) {
        Write-Log "无法自动发现打印机共享" -Level Warning
        $manual = Read-Host "请手动输入打印机共享名（回车退出）"
        if ($manual) { return @($manual) }
        return $null
    }

    Write-Host "共享列表:"
    for ($i=0; $i -lt $shares.Count; $i++) { Write-Host "  $($i+1). $($shares[$i])" }
    return $shares
}

function Select-Printer {
    param($shares)
    if ($shares.Count -eq 0) { return $null }
    if ($shares.Count -eq 1) { Write-Log "自动选择: $($shares[0])" -Level Success; return $shares[0] }
    do {
        $c = Read-Host "请选择序号 (1-$($shares.Count))"
        if ($c -eq 'q') { Exit-Script 3 }
        $n = 0
        if ([int]::TryParse($c, [ref]$n) -and $n -ge 1 -and $n -le $shares.Count) {
            Write-Log "已选择: $($shares[$n-1])" -Level Success
            return $shares[$n-1]
        }
        Write-Host "输入无效" -ForegroundColor Red
    } while ($true)
}

# ---------- 驱动候选 ----------
function Get-DriverCandidates {
    Show-Title "准备驱动列表"
    $cand = @()
    $all = @(Get-PrinterDriver -ErrorAction SilentlyContinue | Select-Object -ExpandProperty Name -Unique)
    if (-not $all) { Write-Log "未找到已安装驱动" -Level Warning; return $cand }
    $generic = @($all | Where-Object { $_ -match 'Generic|Text Only' })
    foreach ($g in $generic) { $cand += $g; Write-Log "通用驱动: $g" -Level Info }
    if (-not $generic) { Write-Log "未找到通用驱动（Generic / Text Only）" -Level Warning }
    foreach ($d in @($all | Where-Object { $cand -notcontains $_ })) { $cand += $d; Write-Log "其他驱动: $d" -Level Info }
    Write-Host "驱动尝试顺序:"
    for ($i=0; $i -lt $cand.Count; $i++) { Write-Host "  $($i+1). $($cand[$i])" }
    return $cand
}

# ---------- 旧式打印机：TCP/IP 端口直连安装 ----------
function Install-WithTcpIpPort {
    param([string]$ShareName, [string]$DriverName)
    # 旧式打印机常因 SMB 共享认证失败，改用 TCP/IP 端口直连
    $portName = "IP_$TargetIP"
    Write-Log "尝试旧式兼容方案: 创建 TCP/IP 端口 $portName 并直连" -Level Info
    $existingPort = Get-PrinterPort -Name $portName -ErrorAction SilentlyContinue
    if (-not $existingPort) {
        Add-PrinterPort -Name $portName -PrinterHostAddress $TargetIP -ErrorAction SilentlyContinue
        Start-Sleep 1
    }
    if (-not (Get-PrinterPort -Name $portName -ErrorAction SilentlyContinue)) {
        Write-Log "创建 TCP/IP 端口失败（可能需要驱动支持）" -Level Warning
        return $false
    }
    $printerName = "$ShareName (IP直连)"
    $exists = Get-Printer -Name $printerName -ErrorAction SilentlyContinue
    if (-not $exists -and $DriverName) {
        Add-Printer -Name $printerName -DriverName $DriverName -PortName $portName -ErrorAction SilentlyContinue
    }
    $p = Get-Printer -Name $printerName -ErrorAction SilentlyContinue
    if ($p) {
        $script:Method = "TCP/IP 端口直连 ($DriverName)"
        $script:UsedDriver = $p.DriverName
        Write-Log "旧式方案安装成功: $printerName" -Level Success
        Write-Host "  提示: 已创建 IP 直连打印机「$printerName」，即使共享服务器不在线也可打印。" -ForegroundColor Magenta
        return $true
    }
    return $false
}

# ---------- 安装打印机 ----------
function Install-Printer {
    param([string]$ShareName, [string[]]$DriverCandidates)
    $unc = "\\$TargetIP\$ShareName"
    Show-Title "正在安装 $ShareName"

    net use $unc /delete 2>$null | Out-Null
    net use "\\$TargetIP\IPC$" /delete 2>$null | Out-Null
    if (-not (Connect-ToRemoteHost $TargetIP $Credential)) { Write-Log "认证失败" -Level Error; return $false }

    $exist = Get-Printer -Name $ShareName -ErrorAction SilentlyContinue
    if ($exist) {
        Write-Log "打印机已存在" -Level Success
        $script:Method = "已存在"; $script:Success = $true; $script:UsedDriver = $exist.DriverName
        return $true
    }

    # 方法1: Add-PrinterConnection（自动下载驱动）
    Write-Log "尝试方法1: Add-PrinterConnection" -Level Info
    try {
        Add-PrinterConnection -Name $unc -ErrorAction Stop
        Start-Sleep 2
        $p = Get-Printer -Name $ShareName -ErrorAction SilentlyContinue
        if ($p) {
            $script:Method="Add-PrinterConnection"; $script:Success=$true; $script:UsedDriver=$p.DriverName
            Write-Log "方法1 安装成功" -Level Success
            return $true
        } else { throw "命令成功但打印机未出现" }
    } catch { Write-Log "方法1 失败: $_" -Level Warning }

    # 方法2: PrintUIEntry /in（系统自动选驱动）
    Write-Log "尝试方法2: PrintUIEntry /in" -Level Info
    $arg = "printui.dll,PrintUIEntry /in /n `"$unc`""
    $proc = Start-Process rundll32.exe -ArgumentList $arg -NoNewWindow -Wait -PassThru
    if ($proc.ExitCode -eq 0) {
        Start-Sleep 2
        $p = Get-Printer -Name $ShareName -ErrorAction SilentlyContinue
        if ($p) {
            $script:Method="PrintUIEntry /in"; $script:Success=$true; $script:UsedDriver=$p.DriverName
            Write-Log "方法2 安装成功" -Level Success
            return $true
        }
    } else { Write-Log "方法2 退出码: $($proc.ExitCode)" -Level Warning }

    # 方法3: 逐个候选驱动
    if ($DriverCandidates.Count -gt 0) {
        Write-Log "尝试方法3: 候选驱动" -Level Info
        foreach ($drv in $DriverCandidates) {
            Write-Log "尝试驱动: $drv" -Level Info
            $arg = "printui.dll,PrintUIEntry /in /n `"$unc`" /m `"$drv`""
            $proc = Start-Process rundll32.exe -ArgumentList $arg -NoNewWindow -Wait -PassThru
            if ($proc.ExitCode -ne 0) { Write-Log "驱动 '$drv' 退出码: $($proc.ExitCode)" -Level Warning; continue }
            Start-Sleep 2
            $p = Get-Printer -Name $ShareName -ErrorAction SilentlyContinue
            if ($p) {
                $script:Method="候选驱动 ($drv)"; $script:Success=$true; $script:UsedDriver=$p.DriverName
                Write-Log "方法3 安装成功" -Level Success
                return $true
            }
        }
    }

    # 方法4: 旧式 TCP/IP 端口直连（不依赖 SMB 共享）
    Write-Log "尝试方法4: 旧式 TCP/IP 端口直连" -Level Info
    foreach ($drv in $DriverCandidates) {
        if (Install-WithTcpIpPort $ShareName $drv) {
            $script:Success = $true
            return $true
        }
    }

    # 方法5: 手动输入驱动名
    $manualDrv = Read-Host "自动方案均失败，请手动输入驱动名（回车跳过）"
    if ($manualDrv) {
        if (Get-PrinterDriver -Name $manualDrv -ErrorAction SilentlyContinue) {
            Write-Log "尝试手动驱动: $manualDrv" -Level Info
            $arg = "printui.dll,PrintUIEntry /in /n `"$unc`" /m `"$manualDrv`""
            $proc = Start-Process rundll32.exe -ArgumentList $arg -NoNewWindow -Wait -PassThru
            if ($proc.ExitCode -eq 0) {
                Start-Sleep 2
                $p = Get-Printer -Name $ShareName -ErrorAction SilentlyContinue
                if ($p) {
                    $script:Method="手动驱动 ($manualDrv)"; $script:Success=$true; $script:UsedDriver=$p.DriverName
                    Write-Log "手动驱动安装成功" -Level Success
                    return $true
                }
            }
        } else { Write-Log "驱动 '$manualDrv' 不存在" -Level Error }
    }

    # 方法6: PrintUIEntry /ga（所有用户，备用）
    Write-Log "尝试方法6: PrintUIEntry /ga" -Level Info
    $arg = "printui.dll,PrintUIEntry /ga /n `"$unc`""
    $proc = Start-Process rundll32.exe -ArgumentList $arg -NoNewWindow -Wait -PassThru
    if ($proc.ExitCode -eq 0) {
        Start-Sleep 2
        $p = Get-Printer -Name $ShareName -ErrorAction SilentlyContinue
        if ($p) {
            $script:Method="PrintUIEntry /ga"; $script:Success=$true; $script:UsedDriver=$p.DriverName
            Write-Log "方法6 安装成功" -Level Success
            return $true
        }
    }

    Write-Log "所有安装方法均失败" -Level Error
    return $false
}

# ---------- 主流程 ----------
$shares = Discover-Shares
if (-not $shares -or $shares.Count -eq 0) {
    Write-Log "未发现共享，退出" -Level Error
    Exit-Script 3
}
$sel = Select-Printer $shares
if (-not $sel) {
    Write-Log "未选择打印机，退出" -Level Error
    Exit-Script 4
}
$drvList = Get-DriverCandidates
$null = Install-Printer $sel $drvList

# 结果输出
Write-Host ""
if ($Success) {
    Write-Host "[成功] 打印机已连接" -ForegroundColor Green
    Write-Host "  名称: $sel"
    Write-Host "  方式: $Method"
    Write-Host "  驱动: $UsedDriver"
} else {
    Write-Host "[失败] 连接未成功" -ForegroundColor Red
    Write-Host "  手动路径: \\$TargetIP\$sel  用户: $FullUsername"
    Write-Log "建议: 运行「权限修复脚本」后重试；旧式打印机请在权限修复中开启 SMB1" -Level Info
}

# 凭据清理
if (-not $KeepCredential) {
    Remove-Credential $TargetIP
} else {
    Write-Host "  凭据已保留（-KeepCredential），可下次免密连接" -ForegroundColor Gray
}

Write-Host "日志: $LogFile" -ForegroundColor Gray
Copy-Item $LogFile $DesktopLog -Force -ErrorAction SilentlyContinue
Write-Log "脚本执行完毕"
