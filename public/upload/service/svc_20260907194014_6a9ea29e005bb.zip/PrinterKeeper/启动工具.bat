@echo off
rem PrinterKeeper Toolbox Launcher (Compatible Version Entry)
powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0PrinterKeeper_Toolbox.ps1"
if errorlevel 1 pause
